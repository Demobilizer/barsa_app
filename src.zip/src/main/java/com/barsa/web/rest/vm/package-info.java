/**
 * View Models used by Spring MVC REST controllers.
 */
package com.barsa.web.rest.vm;
