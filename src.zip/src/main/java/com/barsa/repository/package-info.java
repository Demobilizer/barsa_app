/**
 * Spring Data JPA repositories.
 */
package com.barsa.repository;
