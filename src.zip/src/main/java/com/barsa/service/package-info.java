/**
 * Service layer beans.
 */
package com.barsa.service;
