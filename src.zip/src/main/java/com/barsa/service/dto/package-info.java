/**
 * Data Transfer Objects.
 */
package com.barsa.service.dto;
