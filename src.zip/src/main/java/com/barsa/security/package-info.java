/**
 * Spring Security configuration.
 */
package com.barsa.security;
