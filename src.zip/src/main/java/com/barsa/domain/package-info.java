/**
 * JPA domain objects.
 */
package com.barsa.domain;
