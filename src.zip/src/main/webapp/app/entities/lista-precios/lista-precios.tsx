import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Col, Row, Table } from 'reactstrap';
import { Translate, ICrudGetAllAction } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { IRootState } from 'app/shared/reducers';
import { getEntities } from './lista-precios.reducer';
import { IListaPrecios } from 'app/shared/model/lista-precios.model';
import { APP_DATE_FORMAT, APP_LOCAL_DATE_FORMAT } from 'app/config/constants';

export interface IListaPreciosProps extends StateProps, DispatchProps, RouteComponentProps<{ url: string }> {}

export const ListaPrecios = (props: IListaPreciosProps) => {
  useEffect(() => {
    props.getEntities();
  }, []);

  const { listaPreciosList, match, loading } = props;
  return (
    <div>
      <h2 id="lista-precios-heading">
        <Translate contentKey="barsaAppApp.listaPrecios.home.title">Lista Precios</Translate>
        <Link to={`${match.url}/new`} className="btn btn-primary float-right jh-create-entity" id="jh-create-entity">
          <FontAwesomeIcon icon="plus" />
          &nbsp;
          <Translate contentKey="barsaAppApp.listaPrecios.home.createLabel">Create new Lista Precios</Translate>
        </Link>
      </h2>
      <div className="table-responsive">
        {listaPreciosList && listaPreciosList.length > 0 ? (
          <Table responsive>
            <thead>
              <tr>
                <th>
                  <Translate contentKey="global.field.id">ID</Translate>
                </th>
                <th>
                  <Translate contentKey="barsaAppApp.listaPrecios.descripcion">Descripcion</Translate>
                </th>
                <th>
                  <Translate contentKey="barsaAppApp.listaPrecios.porcentaje">Porcentaje</Translate>
                </th>
                <th>
                  <Translate contentKey="barsaAppApp.listaPrecios.valor">Valor</Translate>
                </th>
                <th />
              </tr>
            </thead>
            <tbody>
              {listaPreciosList.map((listaPrecios, i) => (
                <tr key={`entity-${i}`}>
                  <td>
                    <Button tag={Link} to={`${match.url}/${listaPrecios.id}`} color="link" size="sm">
                      {listaPrecios.id}
                    </Button>
                  </td>
                  <td>{listaPrecios.descripcion}</td>
                  <td>{listaPrecios.porcentaje}</td>
                  <td>{listaPrecios.valor}</td>
                  <td className="text-right">
                    <div className="btn-group flex-btn-group-container">
                      <Button tag={Link} to={`${match.url}/${listaPrecios.id}`} color="info" size="sm">
                        <FontAwesomeIcon icon="eye" />{' '}
                        <span className="d-none d-md-inline">
                          <Translate contentKey="entity.action.view">View</Translate>
                        </span>
                      </Button>
                      <Button tag={Link} to={`${match.url}/${listaPrecios.id}/edit`} color="primary" size="sm">
                        <FontAwesomeIcon icon="pencil-alt" />{' '}
                        <span className="d-none d-md-inline">
                          <Translate contentKey="entity.action.edit">Edit</Translate>
                        </span>
                      </Button>
                      <Button tag={Link} to={`${match.url}/${listaPrecios.id}/delete`} color="danger" size="sm">
                        <FontAwesomeIcon icon="trash" />{' '}
                        <span className="d-none d-md-inline">
                          <Translate contentKey="entity.action.delete">Delete</Translate>
                        </span>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          !loading && (
            <div className="alert alert-warning">
              <Translate contentKey="barsaAppApp.listaPrecios.home.notFound">No Lista Precios found</Translate>
            </div>
          )
        )}
      </div>
    </div>
  );
};

const mapStateToProps = ({ listaPrecios }: IRootState) => ({
  listaPreciosList: listaPrecios.entities,
  loading: listaPrecios.loading
});

const mapDispatchToProps = {
  getEntities
};

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(ListaPrecios);
